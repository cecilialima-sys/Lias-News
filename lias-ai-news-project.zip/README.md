
# LIAS News

Portal de notícias da Liga de Inteligência Artificial na Saúde (LIAS) - UNIFAL.

## Tecnologias
- HTML
- CSS
- JavaScript

## Estrutura
Home + duas abas:
- Atualizações em IA
- IA na Saúde
