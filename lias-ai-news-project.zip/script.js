
fetch("data/noticias.json")
.then(response => response.json())
.then(data => {

const container = document.getElementById("news-container");

data.forEach(noticia => {

const card = document.createElement("div");
card.className = "news-card";

card.innerHTML = `
<h3>${noticia.titulo}</h3>
<p>${noticia.resumo}</p>
<small>${noticia.data}</small>
`;

container.appendChild(card);

});

});
